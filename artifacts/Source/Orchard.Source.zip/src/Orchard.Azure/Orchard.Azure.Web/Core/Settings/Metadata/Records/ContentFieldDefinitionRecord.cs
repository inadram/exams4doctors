namespace Orchard.Core.Settings.Metadata.Records {
    public class ContentFieldDefinitionRecord {
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
    }
}
