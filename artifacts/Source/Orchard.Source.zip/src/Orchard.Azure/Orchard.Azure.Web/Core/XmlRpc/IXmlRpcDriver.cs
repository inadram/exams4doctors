﻿namespace Orchard.Core.XmlRpc {
    public interface IXmlRpcDriver {
        void Process(object item);
    }
}