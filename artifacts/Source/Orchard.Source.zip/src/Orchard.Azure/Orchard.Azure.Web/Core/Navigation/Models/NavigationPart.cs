﻿using Orchard.ContentManagement;

namespace Orchard.Core.Navigation.Models {
    /// <summary>
    /// Allows the management of Content Menu Items associated with a Content Item
    /// </summary>
    public class NavigationPart : ContentPart {
    }
}