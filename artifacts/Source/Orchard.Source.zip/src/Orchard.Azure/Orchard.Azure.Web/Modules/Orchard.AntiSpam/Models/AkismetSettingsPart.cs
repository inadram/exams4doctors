﻿using Orchard.ContentManagement;

namespace Orchard.AntiSpam.Models {
    public class AkismetSettingsPart : ContentPart<AkismetSettingsPartRecord> {
    }
}