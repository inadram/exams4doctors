﻿using Orchard.ContentManagement;

namespace Orchard.AntiSpam.Models {
    public class SubmissionLimitPart : ContentPart {
    }
}