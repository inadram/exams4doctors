#ifndef _PRECOMP_H
#define _PRECOMP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <winsock2.h>
#include <windows.h>

#include <ws2tcpip.h>
#include <mswsock.h>

#endif // _PRECOMP_H
