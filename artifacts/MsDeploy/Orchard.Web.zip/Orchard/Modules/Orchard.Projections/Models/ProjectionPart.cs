﻿using Orchard.ContentManagement;

namespace Orchard.Projections.Models {
    public class ProjectionPart : ContentPart<ProjectionPartRecord> {
    }
}