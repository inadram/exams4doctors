﻿namespace Orchard.Media.ViewModels {
    public class MediaFolderEditPropertiesViewModel {
        public string Name { get; set; }
        public string MediaPath { get; set; }
    }
}
