﻿namespace Orchard.Packaging.Models {
    public class PackagingSource {
        public virtual int Id { get; set; }
        public virtual string FeedTitle { get; set; }
        public virtual string FeedUrl { get; set; }
    }
}