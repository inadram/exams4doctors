﻿using System.Collections.Generic;

namespace Orchard.ContentTypes.ViewModels {
    public class ListContentPartsViewModel {
        public IEnumerable<EditPartViewModel> Parts { get; set; }
    }
}