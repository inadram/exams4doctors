﻿namespace Orchard.Comments.ViewModels {
    public class EditCommentsViewModel {
    }
}
