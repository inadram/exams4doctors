namespace Orchard.Comments.Models {
    public enum CommentStatus {
        Pending,
        Approved,
        Spam
    }
}