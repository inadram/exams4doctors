using Orchard.ContentManagement;

namespace Orchard.Comments.Models {
    public class CommentsContainerPart : ContentPart {
    }
}